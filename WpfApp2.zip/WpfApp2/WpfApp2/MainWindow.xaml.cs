﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void redblue_Click(object sender, RoutedEventArgs e)
        {
            grid1.Background = Brushes.Red;
            grid2.Background = Brushes.Blue;
            Settings.Foreground = Brushes.Blue;
            redblue.Background = Brushes.Red;
            redblue.Foreground = Brushes.Blue;
            redblue.BorderBrush = Brushes.Red;
            greenyellow.Background = Brushes.Red;
            greenyellow.Foreground = Brushes.Blue;
            greenyellow.BorderBrush = Brushes.Red;
            blueyellow.Background = Brushes.Red;
            blueyellow.Foreground = Brushes.Blue;
            blueyellow.BorderBrush = Brushes.Red;
            redyellow.Background = Brushes.Red;
            redyellow.Foreground = Brushes.Blue;
            redyellow.BorderBrush = Brushes.Red;
            blackwhite.Background = Brushes.Red;
            blackwhite.Foreground = Brushes.Blue;
            blackwhite.BorderBrush = Brushes.Red;
            TopText.Foreground = Brushes.Red;
            MidText.Foreground = Brushes.Red;
            bottext.Foreground = Brushes.Red;
        }

        private void greenyellow_Click(object sender, RoutedEventArgs e)
        {
            grid1.Background = Brushes.Green;
            grid2.Background = Brushes.Yellow;
            Settings.Foreground = Brushes.Yellow;
            redblue.Background = Brushes.Green;
            redblue.Foreground = Brushes.Yellow;
            redblue.BorderBrush = Brushes.Green;
            greenyellow.Background = Brushes.Green;
            greenyellow.Foreground = Brushes.Yellow;
            greenyellow.BorderBrush = Brushes.Green;
            blueyellow.Background = Brushes.Green;
            blueyellow.Foreground = Brushes.Yellow;
            blueyellow.BorderBrush = Brushes.Green;
            redyellow.Background = Brushes.Green;
            redyellow.Foreground = Brushes.Yellow;
            redyellow.BorderBrush = Brushes.Green;
            blackwhite.Background = Brushes.Green;
            blackwhite.Foreground = Brushes.Yellow;
            blackwhite.BorderBrush = Brushes.Green;
            TopText.Foreground = Brushes.Green;
            MidText.Foreground = Brushes.Green;
            bottext.Foreground = Brushes.Green;
        }

        private void blueyellow_Click(object sender, RoutedEventArgs e)
        {
            grid1.Background = Brushes.Blue;
            grid2.Background = Brushes.Yellow;
            Settings.Foreground = Brushes.Yellow;
            redblue.Background = Brushes.Blue;
            redblue.Foreground = Brushes.Yellow;
            redblue.BorderBrush = Brushes.Blue;
            greenyellow.Background = Brushes.Blue;
            greenyellow.Foreground = Brushes.Yellow;
            greenyellow.BorderBrush = Brushes.Blue;
            blueyellow.Background = Brushes.Blue;
            blueyellow.Foreground = Brushes.Yellow;
            blueyellow.BorderBrush = Brushes.Blue;
            redyellow.Background = Brushes.Blue;
            redyellow.Foreground = Brushes.Yellow;
            redyellow.BorderBrush = Brushes.Blue;
            blackwhite.Background = Brushes.Blue;
            blackwhite.Foreground = Brushes.Yellow;
            blackwhite.BorderBrush = Brushes.Blue;
            TopText.Foreground = Brushes.Blue;
            MidText.Foreground = Brushes.Blue;
            bottext.Foreground = Brushes.Blue;
        }

        private void redyellow_Click(object sender, RoutedEventArgs e)
        {
            grid1.Background = Brushes.Red;
            grid2.Background = Brushes.Yellow;
            Settings.Foreground = Brushes.Yellow;
            redblue.Background = Brushes.Red;
            redblue.Foreground = Brushes.Yellow;
            redblue.BorderBrush = Brushes.Red;
            greenyellow.Background = Brushes.Red;
            greenyellow.Foreground = Brushes.Yellow;
            greenyellow.BorderBrush = Brushes.Red;
            blueyellow.Background = Brushes.Red;
            blueyellow.Foreground = Brushes.Yellow;
            blueyellow.BorderBrush = Brushes.Red;
            redyellow.Background = Brushes.Red;
            redyellow.Foreground = Brushes.Yellow;
            redyellow.BorderBrush = Brushes.Red;
            blackwhite.Background = Brushes.Red;
            blackwhite.Foreground = Brushes.Yellow;
            blackwhite.BorderBrush = Brushes.Red;
            TopText.Foreground = Brushes.Red;
            MidText.Foreground = Brushes.Red;
            bottext.Foreground = Brushes.Red;
        }

        private void blackwhite_Click(object sender, RoutedEventArgs e)
        {
            grid1.Background = Brushes.Black;
            grid2.Background = Brushes.White;
            Settings.Foreground = Brushes.White;
            redblue.Background = Brushes.Black;
            redblue.Foreground = Brushes.White;
            redblue.BorderBrush = Brushes.Black;
            greenyellow.Background = Brushes.Black;
            greenyellow.Foreground = Brushes.White;
            greenyellow.BorderBrush = Brushes.Black;
            blueyellow.Background = Brushes.Black;
            blueyellow.Foreground = Brushes.White;
            blueyellow.BorderBrush = Brushes.Black;
            redyellow.Background = Brushes.Black;
            redyellow.Foreground = Brushes.White;
            redyellow.BorderBrush = Brushes.Black;
            blackwhite.Background = Brushes.Black;
            blackwhite.Foreground = Brushes.White;
            blackwhite.BorderBrush = Brushes.Black;
            TopText.Foreground = Brushes.Black;
            MidText.Foreground = Brushes.Black;
            bottext.Foreground = Brushes.Black;
        }
    }
}
          //  grid1.Visibility = Visibility.Visible;
          //  grid1.Background = Brushes.Purple;
          //  button2.Background = Brushes.Black;
          //  Brush a1 = button2.Background;
          //  button2.Foreground = Brushes.White;
           // Brush b1 = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#CBFFFA"));
           // Brush b2 = new SolidColorBrush(Color.FromArgb(100,25,25,25));
           // kwadrat.Fill = b1;