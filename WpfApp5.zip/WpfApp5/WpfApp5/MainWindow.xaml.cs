﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp5
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void przycisk_Click(object sender, RoutedEventArgs e)
        {
            var t = text.Text;

            liczbaznak.Text = t.Length.ToString();

            int spec = 0;
            int max = 0;
            var res = "";
            char sp = ' ';

            for (int i = 0; i < t.Length; i++)
            {
                int count = 0;
                foreach (var ch in t)
                {
                    if (ch == t[i])
                        count++;
                }
                if (count > max)
                {
                    max = count;
                    res = t[i].ToString();
                }
            }
            var speccount = 0;
            najczensciejznak.Text = res;
            string specialChar = @"\|!#$%&/()=?»«@£§€{}.-;'<>_,";
            foreach (var item in specialChar)
            {
                foreach(var ch in t)
                {
                    if (ch == item)
                    {
                        speccount++;
                    }
                }
            }
            specjalneznak.Text = speccount.ToString();
            speccount = 0;
            var spacecount = 0;
            foreach(var ch in t)
            {
                if(ch == sp)
                {
                    spacecount++;
                }
            }
            spacjaznak.Text = spacecount.ToString();
            spacecount = 0;
            var numcount = 0;
            string Numba = "1234567890";
            foreach (var item in Numba)
            {
                foreach (var ch in t)
                {
                    if (ch == item)
                    {
                        numcount++;
                    }
                }
            }
            cyfryznak.Text = numcount.ToString();
            numcount = 0;



        }
    }
}
