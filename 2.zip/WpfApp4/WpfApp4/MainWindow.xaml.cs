﻿using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Linq;

namespace WpfApp4
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                string fileContent = File.ReadAllText(filePath, Encoding.UTF8);
                OriginalContentTextBox.Text = fileContent;
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;
                File.WriteAllText(filePath, ModifiedContentTextBox.Text, Encoding.UTF8);
            }
        }

        







        private void ChangeCaseButton_Click_1(object sender, RoutedEventArgs e)
        {
            string inputText = OriginalContentTextBox.Text;
            char[] charArray = inputText.ToCharArray();
            for (int i = 0; i < charArray.Length; i++)
            {
                if (i % 2 == 1)
                {
                    charArray[i] = char.IsUpper(charArray[i]) ? char.ToLower(charArray[i]) : char.ToUpper(charArray[i]);
                }
            }
            ModifiedContentTextBox.Text = new string(charArray);
        }

        private void CapitalizeWordsButton_Click_1(object sender, RoutedEventArgs e)
        {
            string inputText = OriginalContentTextBox.Text;
            string[] words = inputText.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                if (!string.IsNullOrEmpty(words[i]))
                {
                    words[i] = char.ToUpper(words[i][0]) + words[i].Substring(1);
                }
            }
            ModifiedContentTextBox.Text = string.Join(" ", words);
        }

        private void RemovePolishCharsButton_Click_1(object sender, RoutedEventArgs e)
        {
            string inputText = OriginalContentTextBox.Text;
            string withoutPolishChars = new string(inputText.Select(c => c == 'ą' ? 'a' : c == 'ć' ? 'c' : c == 'ę' ? 'e' : c == 'ł' ? 'l' : c == 'ń' ? 'n' : c == 'ó' ? 'o' : c == 'ś' ? 's' : c == 'ź' ? 'z' : c == 'ż' ? 'z' : c).ToArray());
            ModifiedContentTextBox.Text = withoutPolishChars;
        }

        private void RemoveStringButton_Click_1(object sender, RoutedEventArgs e)
        {
            string inputText = OriginalContentTextBox.Text;
            string textToRemove = SearchTextBox.Text;

            ModifiedContentTextBox.Text = "";
        }

        private void ReverseTextButton_Click_1(object sender, RoutedEventArgs e)
        {
            string inputText = OriginalContentTextBox.Text;
            char[] charArray = inputText.ToCharArray();
            Array.Reverse(charArray);
            ModifiedContentTextBox.Text = new string(charArray);
        }


    }
}
