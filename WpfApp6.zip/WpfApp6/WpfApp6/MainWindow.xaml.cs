﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            leftup.Visibility = Visibility.Hidden;
            up.Visibility = Visibility.Hidden;
            rightup.Visibility = Visibility.Hidden;
            left.Visibility = Visibility.Hidden;
            center.Visibility = Visibility.Hidden;
            right.Visibility = Visibility.Hidden;
            leftdown.Visibility = Visibility.Hidden;
            down.Visibility = Visibility.Hidden;
            rightdown.Visibility = Visibility.Hidden;


        }
        bool iscircletime = true;
        int[,] score = { {0,0,0}, {0,0,0 }, {0,0,0} };
        int win = 0;
        int moves = 0;

       
        private void leftup_Click(object sender, RoutedEventArgs e)
        {
            if(iscircletime)
            {
                leftup.Content = "O";
                leftup.IsEnabled = false;
                iscircletime = false;
                score[0, 0] = 1;
                moves += 1;
            } else
            {
                leftup.Content = "X";
                leftup.IsEnabled = false;
                iscircletime = true;
                score[0, 0] = 10;
                moves += 1;
            }
            for(int i = 0;i<=2;i++) {
                if (score[i, 0] + score[i,1] + score[i, 2] == 3 || score[0,i] + score[1,i] + score[2,i]==3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2]+score[1, 1]+score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                } else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }

        }

        private void up_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                up.Content = "O";
                up.IsEnabled = false;
                iscircletime = false;
                score[0, 1] = 1;
                moves += 1;
            }
            else
            {
                up.Content = "X";
                up.IsEnabled = false;
                iscircletime = true;
                score[0, 1] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void rightup_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                rightup.Content = "O";
                rightup.IsEnabled = false;
                iscircletime = false;
                score[0, 2] = 1;
                moves += 1;
            }
            else
            {
                rightup.Content = "X";
                rightup.IsEnabled = false;
                iscircletime = true;
                score[0, 2] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void left_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                left.Content = "O";
                left.IsEnabled = false;
                iscircletime = false;
                score[1, 0] = 1;
                moves += 1;
            }
            else
            {
                left.Content = "X";
                left.IsEnabled = false;
                iscircletime = true;
                score[1, 0] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void center_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                center.Content = "O";
                center.IsEnabled = false;
                iscircletime = false;
                score[1, 1] = 1;
                moves += 1;
            }
            else
            {
                center.Content = "X";
                center.IsEnabled = false;
                iscircletime = true;
                score[1, 1] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void right_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                right.Content = "O";
                right.IsEnabled = false;
                iscircletime = false;
                score[1, 2] = 1;
                moves += 1;
            }
            else
            {
                right.Content = "X";
                right.IsEnabled = false;
                iscircletime = true;
                score[1, 2] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void leftdown_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                leftdown.Content = "O";
                leftdown.IsEnabled = false;
                iscircletime = false;
                score[2, 0] = 1;
                moves += 1;
            }
            else
            {
                leftdown.Content = "X";
                leftdown.IsEnabled = false;
                iscircletime = true;
                score[2, 0] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void down_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                down.Content = "O";
                down.IsEnabled = false;
                iscircletime = false;
                score[2, 1] = 1;
                moves += 1;
            }
            else
            {
                down.Content = "X";
                down.IsEnabled = false;
                iscircletime = true;
                score[2, 1] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void rightdown_Click(object sender, RoutedEventArgs e)
        {
            if (iscircletime)
            {
                rightdown.Content = "O";
                rightdown.IsEnabled = false;
                iscircletime = false;
                score[2, 2] = 1;
                moves += 1;
            }
            else
            {
                rightdown.Content = "X";
                rightdown.IsEnabled = false;
                iscircletime = true;
                score[2, 2] = 10;
                moves += 1;
            }
            for (int i = 0; i <= 2; i++)
            {
                if (score[i, 0] + score[i, 1] + score[i, 2] == 3 || score[0, i] + score[1, i] + score[2, i] == 3 || score[0, 0] + score[1, 1] + score[2, 2] == 3 || score[0, 2] + score[1, 1] + score[2, 0] == 3)
                {
                    winnertext.Text = "O wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
                else if (score[i, 0] + score[i, 1] + score[i, 2] == 30 || score[0, i] + score[1, i] + score[2, i] == 30 || score[0, 0] + score[1, 1] + score[2, 2] == 30 || score[0, 2] + score[1, 1] + score[2, 0] == 30)
                {
                    winnertext.Text = "X wins";
                    leftup.IsEnabled = false;
                    up.IsEnabled = false;
                    rightup.IsEnabled = false;
                    left.IsEnabled = false;
                    center.IsEnabled = false;
                    right.IsEnabled = false;
                    leftdown.IsEnabled = false;
                    down.IsEnabled = false;
                    rightdown.IsEnabled = false;
                }
            }
            if (moves >= 9)
            {
                winnertext.Text = "Draw";
            }
        }

        private void krzyzyk_Click(object sender, RoutedEventArgs e)
        {
            leftup.Visibility = Visibility.Visible;
            up.Visibility = Visibility.Visible;
            rightup.Visibility = Visibility.Visible;
            left.Visibility = Visibility.Visible;
            center.Visibility = Visibility.Visible;
            right.Visibility = Visibility.Visible;
            leftdown.Visibility = Visibility.Visible;
            down.Visibility = Visibility.Visible;
            rightdown.Visibility = Visibility.Visible;
            iscircletime = false;
            kolko.Visibility = Visibility.Hidden;
            krzyzyk.Visibility = Visibility.Hidden;
            whostarts.Visibility = Visibility.Hidden;
        }

        private void kolko_Click(object sender, RoutedEventArgs e)
        {
            leftup.Visibility = Visibility.Visible;
            up.Visibility = Visibility.Visible;
            rightup.Visibility = Visibility.Visible;
            left.Visibility = Visibility.Visible;
            center.Visibility = Visibility.Visible;
            right.Visibility = Visibility.Visible;
            leftdown.Visibility = Visibility.Visible;
            down.Visibility = Visibility.Visible;
            rightdown.Visibility = Visibility.Visible;
            iscircletime = true;
            kolko.Visibility = Visibility.Hidden;
            krzyzyk.Visibility = Visibility.Hidden;
            whostarts.Visibility = Visibility.Hidden;
        }


    }
}
