﻿using System;
using System.Linq;
using System.Windows;

namespace z33
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PrzyciskLicz_Click(object sender, RoutedEventArgs e)
        {
            string wprowadzonyTekst = PoleTekstowe.Text;
            int liczbaSlow = PoliczSlowa(wprowadzonyTekst);
            int brakujaceSlowaDo400 = 400 - liczbaSlow;

            if (string.IsNullOrWhiteSpace(wprowadzonyTekst))
            {
                WyswietlKomunikat("Nie wpisałeś tekstu", liczbaSlow, brakujaceSlowaDo400);
            }
            else if (liczbaSlow < 400)
            {
                WyswietlKomunikat("Minimum 400 słow", liczbaSlow, brakujaceSlowaDo400);
            }
            else
            {
                WyswietlKomunikat("Jest idealnie!", liczbaSlow, 0);
            }
        }

        private int PoliczSlowa(string tekst)
        {
            return tekst.Split(new[] { ' ', '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }

        private void WyswietlKomunikat(string komunikat, int liczbaSlow, int brakujaceSlowa)
        {
            TekstInformacyjny.Text = $"Ilość słów: {liczbaSlow}, Brakuje słów: {brakujaceSlowa}";
            TekstStatusowy.Text = komunikat;
            TekstStatusowy.Visibility = Visibility.Visible;
        }
    }
}
