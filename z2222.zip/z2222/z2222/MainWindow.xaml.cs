﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;

namespace z2222
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PoleNumer_LostFocus(object sender, RoutedEventArgs e)
        {
            string numer = PoleNumer.Text;
            string sciezkaZdjecie = $"{numer}-zdjecie.jpg";
            string sciezkaOdcisk = $"{numer}-odcisk.jpg";

            if (File.Exists(sciezkaZdjecie))
            {
                ObrazOsoba.Source = new BitmapImage(new Uri(sciezkaZdjecie, UriKind.Relative));
            }
            else
            {
                ObrazOsoba.Source = null;
            }

            if (File.Exists(sciezkaOdcisk))
            {
                ObrazOdcisk.Source = new BitmapImage(new Uri(sciezkaOdcisk, UriKind.Relative));
            }
            else
            {
                ObrazOdcisk.Source = null;
            }
        }

        private void PrzyciskOk_Click(object sender, RoutedEventArgs e)
        {
            string imie = PoleImie.Text;
            string nazwisko = PoleNazwisko.Text;
            string kolorOczu = PobierzWybranyKolorOczu();

            if (string.IsNullOrWhiteSpace(imie) || string.IsNullOrWhiteSpace(nazwisko))
            {
                MessageBox.Show("Wprowadź dane", "Błąd", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                MessageBox.Show($"{imie} {nazwisko} kolor oczu {kolorOczu}", "Informacja", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private string PobierzWybranyKolorOczu()
        {
            if (PrzyciskNiebieskie.IsChecked == true)
                return "niebieskie";
            else if (PrzyciskZielone.IsChecked == true)
                return "zielone";
            else
                return "piwne";
        }
    }
}
