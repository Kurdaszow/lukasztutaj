﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace za
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void oblicz_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string nazwaProduktu = nazwa.Text;
                double cenaProduktu = Convert.ToDouble(cena.Text);
                int iloscProduktu = Convert.ToInt32(ilosc.Text);
                Zamowienie order = new Zamowienie(cenaProduktu, iloscProduktu);
                double wartoscZamowienia = order.ObliczWartoscZamowienia(rabat.IsChecked == true, vat.IsChecked == true);
                wartosc.Text = wartoscZamowienia.ToString("C", new System.Globalization.CultureInfo("pl-PL"));
            }
            catch (FormatException)
            {
                MessageBox.Show("coś się nie zgadza","Błąd", MessageBoxButton.OK,MessageBoxImage.Error);
            }
        }

        private void wyczysc_Click(object sender, RoutedEventArgs e)
        {
            nazwa.Clear();
            cena.Clear();
            ilosc.Clear();
            rabat.IsChecked = false;
            vat.IsChecked = false;
            wartosc.Clear();
        }
    }
    public class Zamowienie
    {
        public double Cena { get; set; }
        public double Ilosc { get; set; }
        public Zamowienie(double cenaProduktu, int iloscProduktu)
        {
            Cena = cenaProduktu;
            Ilosc = iloscProduktu;
        }
        public double ObliczWartoscZamowienia(bool rabar,bool vat)
        {
            double wartoscZamowienia = Cena * Ilosc;
            if (rabar)
            {
                wartoscZamowienia *= 0.9;
                
            }
            if (vat)
            {
                wartoscZamowienia *= 1.23;
            }
            return wartoscZamowienia;
        }
    }
}