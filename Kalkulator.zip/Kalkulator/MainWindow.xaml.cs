﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalkulator
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}
		float liczba1 = 0;
		float liczba2 = 0;
		char znak = ' ';
		private void multiply_Click(object sender, RoutedEventArgs e)
		{
			liczba1 = float.Parse(textB.Text);
			textB.Text = "";
			znak = '*';
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{

		}

		private void divide_Click(object sender, RoutedEventArgs e)
		{
			liczba1 += float.Parse(textB.Text);
			textB.Text = "";
			znak = '/';
		}

		private void Button_Click_1(object sender, RoutedEventArgs e)
		{

		}

		private void CA_Click_2(object sender, RoutedEventArgs e)
		{
			liczba1 += float.Parse(textB.Text);
			textB.Text = "";
			znak = ' ';
		}

		private void _9_Click(object sender, RoutedEventArgs e)
		{
			liczba1 += float.Parse(textB.Text);
			textB.Text = "";
			znak = '/';
		}

		private void _8_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "8";
		}

		private void _7_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "7";
		}

		private void subtract_Click(object sender, RoutedEventArgs e)
		{
			liczba1 += float.Parse(textB.Text);
			textB.Text = "";
			znak = '-';
		}

		private void _6_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "6";
		}

		private void _5_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "5";
		}

		private void _4_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "4";
		}

		private void add_Click(object sender, RoutedEventArgs e)
		{
			liczba1 += float.Parse(textB.Text);
			textB.Text = "fefefee";
			znak = '+';
		}

		private void _3_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "3";
		}

		private void _2_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "2";
		}

		private void _1_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "1";
		}

		private void equals_Click(object sender, RoutedEventArgs e)
		{

			liczba2 = float.Parse(textB.Text);
			if (znak == '*')
			{
				textB.Text = (liczba1 * liczba2).ToString();
			}
			if (znak == '/')
			{
				if (liczba2 == 0)
				{
					textB.Text= " nie";
				}
				else
				{
					textB.Text = (liczba1 / liczba2).ToString();
				}
			}
			if (znak == '+')
			{
				textB.Text = (liczba1 + liczba2).ToString();
			}
			if (znak == '-')
			{
				textB.Text = (liczba1 - liczba2).ToString();
			}
			liczba1 = 0;
			liczba2 = 0;
			znak = ' ';
		}

		private void Button_Click_3(object sender, RoutedEventArgs e)
		{

		}

		private void _0_Click(object sender, RoutedEventArgs e)
		{
			textB.Text += "0";
		}

		private void Button_Click_4(object sender, RoutedEventArgs e)
		{

		}
	}
}
