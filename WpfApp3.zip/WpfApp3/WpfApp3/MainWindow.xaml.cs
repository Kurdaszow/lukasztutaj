﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int z;
        int t;
        float tf;
        double db;
        Byte[] b = new Byte[1];
        public MainWindow()
        {
            InitializeComponent();
        }

        private void buttongenerate_Click(object sender, RoutedEventArgs e)
        {
            byteliczba.Text = "";
            t = Int32.Parse(tobox.Text);
            z = Int32.Parse(frombox.Text);
            Random random = new Random();
            int RandomNumber = random.Next(z, t);
            intliczba.Text = RandomNumber.ToString();

            float val = random.NextSingle() * (t - z) + z;
            floatliczba.Text = val.ToString();
            double val3 = random.NextDouble() * (t - z) + z;
            doubleliczba.Text = val3.ToString();
            random.NextBytes(b);
            byteliczba.Text = b[0].ToString();
         //   Random rand = new Random();
          //  Byte[] b = new Byte[10];
          //  rand.NextBytes(b);
          //  for (int i = 0; i < 10; i++)
         //   {
          //      byteliczba.Text += b[i];
          //      byteliczba.Text += " ";
           // }
                



        }
    }
}
