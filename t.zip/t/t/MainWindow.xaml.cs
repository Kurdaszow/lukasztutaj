﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace t
{
    public class Book
    {
        public string Title { get; set; }
        public string Author { get; set; }
        public int Year { get; set; }
        public string Ibs { get; set; }

        public Book(string title, string author, int year, string ibs)
        {
            Title = title;
            Author = author;
            Year = year;
            Ibs = ibs;
        }
        public string PokazKsiazke()
        {
            return $" {Title} {Author} {Year} {Ibs}";
        }
    }
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private List<Book> books = new List<Book>();
        public void Button_Click(object sender, RoutedEventArgs e)
        {

            string title = tytul.Text;
            string author = autor.Text;
            string year = rok.Text;
            int rokk;
                string ibs = ibsn.Text;
            

            tytul.Clear();
            autor.Clear();
            rok.Clear();
            ibsn.Clear();
            if (title == "" || author == "" ||  ibs == "")
            {
                MessageBox.Show("Wprowadź wszystkie dane!");
            }
            else if (!int.TryParse(year, out rokk))
            {
                MessageBox.Show("Podaj Numer!");
            }
            else
            {
            Book newBook = new Book(title, author, rokk, ibs);
                books.Add(newBook);
                UpdateBookList();
            }
        }
        private void UpdateBookList()
        {
            aa.Clear();
            foreach (var book in books)
            {
                aa.AppendText(book.PokazKsiazke() + Environment.NewLine);
            }
        }
    }
}